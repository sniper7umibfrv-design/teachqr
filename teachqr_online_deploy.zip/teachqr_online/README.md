# TEACHQR Online Classroom

A deployable Flask + SQLite application with the original portfolio at `/` and role-separated portals at `/portal?role=teacher` and `/portal?role=student`.

## Start locally

Install Python 3.10+, then from this folder:

```bash
python -m pip install -r requirements.txt
python app.py
```

Open `http://localhost:5000`. Teacher and student accounts use the **same online backend**, so they can access shared data from different devices **when deployed on a publicly reachable server**. The QR code points to your current server's address; localhost QR links won't work from other phones.

## Deploy

Deploy this folder to a Python-compatible hosting service with **persistent disk storage**. Set environment variables:

- `SECRET_KEY`: long randomly generated secret (required for reliable logins across restarts)
- `COOKIE_SECURE=1` when served over HTTPS
- `DATABASE_PATH=/persistent/path/teachqr.db` (optional)
- `UPLOAD_DIR=/persistent/path/uploads` (optional)

Production start command: `waitress-serve --listen=0.0.0.0:$PORT app:app` (if your host does not expand `$PORT`, specify its configured port explicitly). Use HTTPS and a real domain for usable QR join links.

## Features

- Separate teacher/student registration and login, hashed passwords, role-checked API endpoints.
- Teachers create classes, generate scannable QR codes and links, create assignments, set class deadlines and individual student deadlines, and allow late uploads.
- Students join classes by QR/code, upload actual files, and see deadlines and submission status.
- Server enforces due dates and permissions (changing browser code cannot bypass them).
- Teachers download submissions and CSV reports showing submitted, overdue and missing work.

## Notes / production hardening

This is a **deployable starter**, not a fully hardened school production system. Add verified teacher registration/administrator approval (currently users can self-register as teachers), email verification, password resets, rate limits, malware scanning, audit logs, privacy notices, retention policies, backup/restore, and managed storage before handling real student records. Files max 20 MB per upload; file extensions are allowlisted but contents are not virus-scanned. SQLite is suitable for a small deployment on a single persistent instance; use PostgreSQL/object storage for scaling. Use one persistent process/instance or migrate to a managed database. Do not commit the SQLite DB or uploaded files to source control.

## Render Blueprint

This project includes `render.yaml` for a Singapore-region Render web service with a 1 GB persistent disk for SQLite and uploaded files. The Blueprint uses the **Starter paid web-service plan** because this application needs persistent storage; review the current price in Render before applying. The Blueprint generates `SECRET_KEY` automatically and enables secure cookies over HTTPS.

To deploy, put the *contents* of this folder at the root of a GitHub/GitLab/Bitbucket repository, push the default branch, then open the Render Blueprint flow for that repository and apply `render.yaml`. Review the resource plan and any charges before confirming. Do not use the free ephemeral filesystem for real submissions.
