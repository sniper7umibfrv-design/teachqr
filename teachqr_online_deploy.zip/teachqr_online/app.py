import os, sqlite3, secrets, io, csv
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import qrcode

BASE=os.path.dirname(os.path.abspath(__file__))
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config.update(MAX_CONTENT_LENGTH=20*1024*1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE')=='1')
DB=os.environ.get('DATABASE_PATH',os.path.join(BASE,'teachqr.db'))
UPLOAD=os.environ.get('UPLOAD_DIR',os.path.join(BASE,'uploads'))
os.makedirs(UPLOAD,exist_ok=True)

def db():
    c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,passhash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('teacher','student')));
        CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY,teacher_id INTEGER NOT NULL REFERENCES users(id),name TEXT NOT NULL,code TEXT UNIQUE NOT NULL);
        CREATE TABLE IF NOT EXISTS enrollments(class_id INTEGER REFERENCES classes(id),student_id INTEGER REFERENCES users(id),PRIMARY KEY(class_id,student_id));
        CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY,class_id INTEGER REFERENCES classes(id),title TEXT NOT NULL,instructions TEXT NOT NULL DEFAULT '',due TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS overrides(assignment_id INTEGER REFERENCES assignments(id),student_id INTEGER REFERENCES users(id),due TEXT,late_allowed INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(assignment_id,student_id));
        CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY,assignment_id INTEGER REFERENCES assignments(id),student_id INTEGER REFERENCES users(id),stored_name TEXT NOT NULL,original_name TEXT NOT NULL,uploaded_at TEXT NOT NULL,UNIQUE(assignment_id,student_id));''')
init()

def now():return datetime.now(timezone.utc)
def dt(s):return datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(timezone.utc)
def user():
    if not session.get('uid'):return None
    with db() as c:return c.execute('SELECT id,name,email,role FROM users WHERE id=?',(session['uid'],)).fetchone()
def auth(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapped(*a,**kw):
            u=user()
            if not u:return jsonify(error='Please log in'),401
            if role and u['role']!=role:return jsonify(error='Access denied'),403
            if request.method not in ('GET','HEAD') and request.headers.get('X-CSRF-Token')!=session.get('csrf'):return jsonify(error='Invalid security token'),403
            return fn(*a,**kw)
        return wrapped
    return deco

def owner(c,cls):return c.execute('SELECT * FROM classes WHERE id=? AND teacher_id=?',(cls,session['uid'])).fetchone()
def student_in(c,cls):return c.execute('SELECT 1 FROM enrollments WHERE class_id=? AND student_id=?',(cls,session['uid'])).fetchone()
def assignment(c,aid):return c.execute('SELECT * FROM assignments WHERE id=?',(aid,)).fetchone()
def info(a,student,c):
    o=c.execute('SELECT * FROM overrides WHERE assignment_id=? AND student_id=?',(a['id'],student)).fetchone()
    due=o['due'] if o and o['due'] else a['due'];late=bool(o and o['late_allowed']);sub=c.execute('SELECT id,original_name,uploaded_at FROM submissions WHERE assignment_id=? AND student_id=?',(a['id'],student)).fetchone()
    return dict(id=a['id'],title=a['title'],instructions=a['instructions'],due=due,late_allowed=late,overdue=now()>dt(due),submission=dict(sub) if sub else None)

@app.get('/')
def index():return render_template('index.html')
@app.get('/portal')
def portal():return render_template('portal.html')
@app.get('/api/me')
def me():return jsonify(user=dict(user()) if user() else None,csrf=session.get('csrf'))
@app.post('/api/register')
def register():
    d=request.get_json(silent=True) or {};email=str(d.get('email','')).strip().lower();name=str(d.get('name','')).strip();pw=str(d.get('password',''));role=d.get('role')
    if role not in ('teacher','student') or '@' not in email or len(name)<2 or len(pw)<8:return jsonify(error='Enter a name, valid email and password of at least 8 characters'),400
    try:
        with db() as c:
            cur=c.execute('INSERT INTO users(email,name,passhash,role) VALUES(?,?,?,?)',(email,name,generate_password_hash(pw),role));uid=cur.lastrowid
    except sqlite3.IntegrityError:return jsonify(error='Email already registered'),409
    session.clear();session['uid']=uid;session['csrf']=secrets.token_urlsafe(32)
    return jsonify(ok=True)
@app.post('/api/login')
def login():
    d=request.get_json(silent=True) or {}
    with db() as c:u=c.execute('SELECT * FROM users WHERE email=? AND role=?',(str(d.get('email','')).strip().lower(),d.get('role'))).fetchone()
    if not u or not check_password_hash(u['passhash'],str(d.get('password',''))):return jsonify(error='Incorrect credentials or portal role'),401
    session.clear();session['uid']=u['id'];session['csrf']=secrets.token_urlsafe(32);return jsonify(ok=True)
@app.post('/api/logout')
@auth()
def logout():session.clear();return jsonify(ok=True)
@app.get('/api/classes')
@auth()
def classes():
    with db() as c:
        if user()['role']=='teacher':rows=c.execute('SELECT * FROM classes WHERE teacher_id=? ORDER BY id DESC',(session['uid'],)).fetchall()
        else:rows=c.execute('SELECT c.* FROM classes c JOIN enrollments e ON e.class_id=c.id WHERE e.student_id=? ORDER BY c.id DESC',(session['uid'],)).fetchall()
        return jsonify(classes=[dict(r) for r in rows])
@app.post('/api/classes')
@auth('teacher')
def create_class():
    name=str((request.get_json() or {}).get('name','')).strip()
    if not name:return jsonify(error='Class name required'),400
    with db() as c:
        code=secrets.token_hex(4).upper();cur=c.execute('INSERT INTO classes(teacher_id,name,code) VALUES(?,?,?)',(session['uid'],name,code))
        return jsonify(id=cur.lastrowid,code=code)
@app.post('/api/join')
@auth('student')
def join():
    code=str((request.get_json() or {}).get('code','')).strip().upper()
    with db() as c:
        cl=c.execute('SELECT * FROM classes WHERE code=?',(code,)).fetchone()
        if not cl:return jsonify(error='Class not found'),404
        c.execute('INSERT OR IGNORE INTO enrollments VALUES(?,?)',(cl['id'],session['uid']))
        return jsonify(id=cl['id'])
@app.get('/api/classes/<int:cls>/details')
@auth()
def details(cls):
    with db() as c:
        if not (owner(c,cls) if user()['role']=='teacher' else student_in(c,cls)):return jsonify(error='Access denied'),403
        cl=c.execute('SELECT * FROM classes WHERE id=?',(cls,)).fetchone();aa=c.execute('SELECT * FROM assignments WHERE class_id=? ORDER BY id DESC',(cls,)).fetchall()
        if user()['role']=='student':return jsonify(cls=dict(cl),assignments=[info(a,session['uid'],c) for a in aa])
        students=c.execute('SELECT u.id,u.name,u.email FROM users u JOIN enrollments e ON e.student_id=u.id WHERE e.class_id=? ORDER BY u.name',(cls,)).fetchall()
        return jsonify(cls=dict(cl),students=[dict(s) for s in students],assignments=[dict(a,records=[dict(student_id=s['id'],student_name=s['name'],**info(a,s['id'],c)) for s in students]) for a in aa])
@app.post('/api/classes/<int:cls>/assignments')
@auth('teacher')
def create_assignment(cls):
    d=request.get_json() or {};title=str(d.get('title','')).strip();due=d.get('due');instructions=str(d.get('instructions',''))
    try:dt(due)
    except (ValueError,TypeError,AttributeError):return jsonify(error='Valid deadline required'),400
    if not title:return jsonify(error='Title required'),400
    with db() as c:
        if not owner(c,cls):return jsonify(error='Access denied'),403
        c.execute('INSERT INTO assignments(class_id,title,instructions,due) VALUES(?,?,?,?)',(cls,title,instructions,due))
    return jsonify(ok=True)
@app.post('/api/assignments/<int:aid>/students/<int:sid>/override')
@auth('teacher')
def override(aid,sid):
    d=request.get_json() or {};due=d.get('due') or None
    if due:
        try:dt(due)
        except (ValueError,TypeError):return jsonify(error='Invalid deadline'),400
    with db() as c:
        a=assignment(c,aid)
        if not a or not owner(c,a['class_id']) or not c.execute('SELECT 1 FROM enrollments WHERE class_id=? AND student_id=?',(a['class_id'],sid)).fetchone():return jsonify(error='Access denied'),403
        c.execute('INSERT INTO overrides(assignment_id,student_id,due,late_allowed) VALUES(?,?,?,?) ON CONFLICT(assignment_id,student_id) DO UPDATE SET due=excluded.due,late_allowed=excluded.late_allowed',(aid,sid,due,int(bool(d.get('late_allowed')))))
    return jsonify(ok=True)
@app.post('/api/assignments/<int:aid>/submit')
@auth('student')
def submit(aid):
    f=request.files.get('file')
    if not f or not f.filename:return jsonify(error='Select a file'),400
    original=secure_filename(f.filename)
    if not original or os.path.splitext(original)[1].lower() not in {'.pdf','.doc','.docx','.txt','.png','.jpg','.jpeg','.ppt','.pptx','.xlsx','.zip'}:return jsonify(error='Unsupported file type'),400
    with db() as c:
        a=assignment(c,aid)
        if not a or not student_in(c,a['class_id']):return jsonify(error='Access denied'),403
        i=info(a,session['uid'],c)
        if i['overdue'] and not i['late_allowed']:return jsonify(error='Deadline passed. Teacher approval is required.'),403
        stored=secrets.token_hex(20)+os.path.splitext(original)[1].lower();path=os.path.join(UPLOAD,stored);f.save(path)
        old=c.execute('SELECT stored_name FROM submissions WHERE assignment_id=? AND student_id=?',(aid,session['uid'])).fetchone()
        c.execute('INSERT INTO submissions(assignment_id,student_id,stored_name,original_name,uploaded_at) VALUES(?,?,?,?,?) ON CONFLICT(assignment_id,student_id) DO UPDATE SET stored_name=excluded.stored_name,original_name=excluded.original_name,uploaded_at=excluded.uploaded_at',(aid,session['uid'],stored,original,now().isoformat()))
        if old:
            try:os.remove(os.path.join(UPLOAD,old['stored_name']))
            except OSError:pass
    return jsonify(ok=True)
@app.get('/api/submissions/<int:sid>/download')
@auth()
def download(sid):
    with db() as c:
        row=c.execute('SELECT s.*,a.class_id FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE s.id=?',(sid,)).fetchone()
        if not row or not (owner(c,row['class_id']) if user()['role']=='teacher' else row['student_id']==session['uid']):abort(403)
        return send_file(os.path.join(UPLOAD,row['stored_name']),as_attachment=True,download_name=row['original_name'])
@app.get('/api/classes/<int:cls>/report')
@auth('teacher')
def report(cls):
    with db() as c:
        if not owner(c,cls):abort(403)
        aa=c.execute('SELECT * FROM assignments WHERE class_id=?',(cls,)).fetchall();ss=c.execute('SELECT u.id,u.name,u.email FROM users u JOIN enrollments e ON e.student_id=u.id WHERE e.class_id=?',(cls,)).fetchall()
        out=io.StringIO();w=csv.writer(out);w.writerow(['Assignment','Student','Email','Deadline UTC','Status','Uploaded UTC','Filename'])
        for a in aa:
            for s in ss:
                i=info(a,s['id'],c);sub=i['submission'];w.writerow([a['title'],s['name'],s['email'],i['due'],'Submitted' if sub else ('Overdue' if i['overdue'] else 'Not submitted'),sub['uploaded_at'] if sub else '',sub['original_name'] if sub else ''])
        data=out.getvalue().encode('utf-8-sig');return send_file(io.BytesIO(data),mimetype='text/csv',as_attachment=True,download_name=f'teachqr_class_{cls}.csv')
@app.get('/api/classes/<int:cls>/qr')
@auth('teacher')
def qr(cls):
    with db() as c:
        cl=owner(c,cls)
        if not cl:abort(403)
    url=request.url_root.rstrip('/')+'/portal?role=student&code='+cl['code'];im=qrcode.make(url);buf=io.BytesIO();im.save(buf,format='PNG');buf.seek(0)
    return send_file(buf,mimetype='image/png')
if __name__=='__main__':app.run(debug=os.environ.get('FLASK_DEBUG')=='1',host='0.0.0.0',port=int(os.environ.get('PORT','5000')))
